# Privacy Policy

**Convorian** | Effective Date: June 2026 | Last Updated: June 2026

---

## 1. Who We Are

Convorian ("we", "us", "our") is an AI-powered sales nurturing and WhatsApp automation platform operated by Convorian Private Limited, India. We help businesses automate lead nurturing and communication through WhatsApp and other channels.

Contact: privacy@convorian.com

---

## 2. What Data We Collect

### From Agents (our customers)
- Name, email address, phone number
- Agency name, location, business details
- Payment information (processed securely by Razorpay — we do not store card details)
- Platform usage data and settings

### From Leads (end-users of our agents)
- Name and phone number (provided by the agent)
- WhatsApp conversation history
- Inferred data: property preferences, budget, intent, engagement score
- Appointment and visit booking information

### Automatically Collected
- IP address, device type, browser type
- Pages visited, time spent, click behaviour
- Error logs and performance data

---

## 3. Why We Collect This Data

We use your data to:
- Provide and operate the Convorian platform
- Power the AI conversation engine
- Send WhatsApp messages on behalf of agents to their leads
- Generate analytics and ROI reports for agents
- Send transactional emails (receipts, alerts, reminders)
- Improve our AI engine and platform (using anonymised data only)
- Comply with legal obligations

---

## 4. How We Store and Protect Your Data

- All data is stored on Supabase (PostgreSQL) with encryption at rest
- Data is hosted on AWS infrastructure in Asia (ap-south-1 region)
- We use Row Level Security (RLS) — each agent can only access their own data
- All connections use HTTPS/TLS encryption in transit
- API keys and tokens are stored encrypted, never in plain text
- Access to production data is restricted to authorised personnel only
- We conduct regular security reviews

---

## 5. Who We Share Data With

We share data only with:
- **Twilio / Meta (WhatsApp):** To send and receive WhatsApp messages
- **Google (Vertex AI / Gemini):** To power AI conversation responses
- **Razorpay:** To process payments
- **Resend:** To send transactional emails
- **Google Cloud Platform:** Our hosting infrastructure

We do not sell your data. We do not share your data with advertisers.

We may share data if required by law, court order, or government authority.

---

## 6. Data Retention

- Agent account data: Retained for duration of subscription + 90 days after cancellation
- Lead and conversation data: Retained for 2 years from last activity
- Payment records: Retained for 7 years (legal requirement)
- After retention period: Data is permanently deleted

---

## 7. Your Rights

You have the right to:
- **Access** your data — request a copy at any time
- **Correct** inaccurate data
- **Delete** your data (right to erasure)
- **Restrict** processing of your data
- **Export** your data in machine-readable format
- **Withdraw consent** at any time

To exercise any of these rights, email: privacy@convorian.com
We will respond within 30 days.

---

## 8. Lead Data & Agent Responsibility

Convorian is a platform. Agents are responsible for:
- Obtaining proper consent from their leads before adding them to Convorian
- Ensuring leads have opted in to receive WhatsApp messages
- Complying with applicable communication laws in their region
- Not uploading data of minors

By using Convorian, agents confirm they have obtained all necessary consents.

---

## 9. Cookies

We use cookies for:
- **Necessary:** Authentication, security, session management
- **Analytics:** Understanding how the platform is used (anonymised)
- **Preferences:** Remembering your settings

You can manage cookie preferences via the cookie banner on our website.

---

## 10. Children's Privacy

Convorian is not directed at children under 18. We do not knowingly collect data from minors. If you believe we have collected data from a minor, contact us immediately.

---

## 11. International Data Transfers

Our servers are located in India and the United States. If you are located outside India, your data may be transferred internationally. We ensure adequate protection through standard contractual clauses and our security practices.

---

## 12. Changes to This Policy

We may update this policy. We will notify you by email and update the "Last Updated" date. Continued use after changes constitutes acceptance.

---

## 13. Grievance Officer

As required under the IT Act 2000 and DPDP Act 2023:

**Grievance Officer:** Shantanu Kulkaarni
**Email:** grievance@convorian.com
**Response time:** Within 30 days of receipt of complaint

---

## 14. Contact Us

Convorian Private Limited
Email: privacy@convorian.com
Website: https://convorian.com
